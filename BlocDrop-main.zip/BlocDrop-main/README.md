![Logo](https://github.com/matan1905/BlocDrop/blob/main/Logo.jpg)

BlocDrop is  a GUI based Smart Contract Builder where you can drag and drop modules from an already predefined set of modules that is provided....these modules will give you functionality and flexibility to design your smart contract based on your need without worrying about the syntax of code...all you need to have Is the logic and algorithm in your head and you can build your own Contracts.  The aim is to expose contract building to the general public
