//moduleName, type, args, display
//Statements

var emptySpace = '<span class="empty-space"></span>';

class Entry extends Module{
  constructor() {
  	super("EntryPoint", "", ["statement","statement"], "When creating the contract do {0}, then {1}");
  }

  parse(){
  	return "(seq)" 
  }

}
contractDetails["base"] = new Entry();



class When extends Module{
  constructor() {
  	super(`when${emptySpace}then${emptySpace}`, "statement", ["variable","statement"], "when {0} then {1}");
  }

  parse(){
  	return "(when)" 
  }

}
blocks.when= ()=> new When();

class If extends Module{
  constructor() {
  	super(`if${emptySpace}then${emptySpace}else${emptySpace}`, "statement", ["variable","statement","statement"], "if {0} then {1} else {2}");
  }

  parse(){
  	return "(if)" 
  }

}
blocks.if= ()=> new If();

class Stop extends Module{
  constructor() {
  	super("stop", "statement", [], "STOP");
  }

  parse(){
  	return "(stop)" 
  }

}
blocks.stop= ()=> new Stop();


class SendFunds extends Module{
  constructor() {
  	super("Send funds", "statement", ["expression","expression"], "Send {0} to {1}");
  }

  parse(){
  	return "(stop)" 
  }

}
blocks.sendfunds= ()=> new SendFunds();

class CreateFunc extends Module{
  constructor() {
  	super("Create contract function", "statement", ["expression","expression[]","statement"], "Create function called {0} that accepts {[1]} and then does {2}");
  }

  parse(){
  	return "(stop)" 
  }

}
blocks.createfunc= ()=> new CreateFunc();

class CreateERC20 extends Module{
  constructor() {
  	super("Create ERC20 Tokens", "statement", ["expression","expression","expression","expression"], "Create A total of {0} tokens called {1} with the symbol {2} and the decimal {3}");
  }

  parse(){
  	return "(stop)" 
  }

}
blocks.createerc20= ()=> new CreateERC20();

class TransferERC20Ownership extends Module{
  constructor() {
  	super("Transfer ERC20 Ownership", "statement", ["expression","expression","expression"], "Transfer {0} of the token {1} to {2}");
  }

  parse(){
  	return "(stop)" 
  }

}
blocks.transfererc20ownership= ()=> new TransferERC20Ownership();






// Expressions
class Numnber extends Module{
  constructor() {
  	super("Number", "variable", [], "<span contenteditable='true'>0</span>");
  }

  parse(){
  	return "1"//Some way of finding the number using uuidv4
  }

}

blocks.number= ()=> new Numnber();

class Text extends Module{
  constructor() {
  	super("Text", "variable", [], "<span contenteditable='true'>Hello</span>");
  }

  parse(){
  	return "\"1\""//Some way of finding the number using uuidv4
  }

}

blocks.text= ()=> new Text();

class Transaction extends Module{
  constructor() {
  	super("Transaction Detail", "expression", [], "The transaction's <select><option>Amount</option> <option>Origin</option> <option>Gas left</option> <option>Gas price</option></select>");
  }

  parse(){
  	return "1"
  }

}

blocks.transaction= ()=> new Transaction();

class Contract extends Module{
  constructor() {
  	super("Contract Detail", "expression", [], "The contract's <select><option>Caller</option> <option>Address</option> <option>Balance</option> <option>Gas price</option></select>");
  }

  parse(){
  	return "1"
  }

}

blocks.contract= ()=> new Contract();

class Block extends Module{
  constructor() {
  	super("Block Detail", "expression", [], "The block's <select><option>Timestamp</option> <option>Number</option> <option>Previous Hash</option> <option>Coinbase</option> <option>Difficulty</option><option>Total gas</option></select>");
  }

  parse(){
  	return "1"
  }

}

blocks.block= ()=> new Block();


class Addition extends Module{
  constructor() {
  	super("Addition", "expression", ["expression[]"], "The sum of {[0]}");
  }

  parse(){
  	return "1"
  }

}
blocks.addition= ()=> new Addition();


class Multipication extends Module{
  constructor() {
  	super("Multipication", "expression", ["expression[]"], "The product of {[0]}");
  }

  parse(){
  	return "1"
  }

}
blocks.multipication= ()=> new Multipication();


class Equality extends Module{
  constructor() {
  	super("Equality", "expression", ["expression", "expression"], "{0} is equal to {1}");
  }

  parse(){
  	return "1"
  }

}
blocks.equality= ()=> new Equality();

class Or extends Module{
  constructor() {
  	super("One is true (OR)", "expression", ["expression[]"], "One of {[0]} is true");
  }

  parse(){
  	return "1"
  }

}
blocks.or= ()=> new Or();

class And extends Module{
  constructor() {
  	super("All are true (AND)", "expression", ["expression[]"], "All of {[0]} are true");
  }

  parse(){
  	return "1"
  }

}
blocks.and= ()=> new And();

class Assignment extends Module{
  constructor() {
  	super("Assignment", "expression", ["expression","expression"], "Set the value of {0} to {1}");
  }

  parse(){
  	return "1"
  }

}
blocks.assignment= ()=> new Assignment();


class GreaterThan extends Module{
  constructor() {
  	super("GreaterThan", "expression", ["expression","expression"], "{0} is greater than {1}");
  }

  parse(){
  	return "1"
  }

}
blocks.greaterthan = ()=> new GreaterThan();


class SmallerThan extends Module{
  constructor() {
  	super("SmallerThan", "expression", ["expression","expression"], "{0} is smaller than {1}");
  }

  parse(){
  	return "1"
  }

}
blocks.smallerthan = ()=> new GreaterThan();







