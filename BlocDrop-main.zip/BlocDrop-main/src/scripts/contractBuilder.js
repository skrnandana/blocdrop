
var blocks = {}; //List of modules

var contractDetails = {} //Representation of the contract
class Module {
  constructor(moduleName, type, args, display) {
  	this.innerBlocks =[];
  	this.moduleName=moduleName; //Module name
    this.type=type; // A string containing what type it is, for example: "statement"
    this.args=args; // array of arguments and their types, for example: ["boolean","statement"]
    this.display=display; // string that is represented to the user(using args), for example: "when {0} then {[1]}" where {x} is regular type and {[y]} is multiple statements
    //Note - display can also be <input type="number" />

    for (var i = 0; i < args.length; i++) {
    	if(args[i].endsWith("[]")){
    		this.innerBlocks.push([uuidv4()])
    	}
    	else this.innerBlocks.push(uuidv4());
    }

    if (this.parse === undefined) {
      throw new TypeError("Please create a parse function or variable that will produce the result of parsing this function");
    }
  }

  getDisplay(){
  	var htmlDisplay = this.display;
  	for (var i = 0; i < this.innerBlocks.length; i++) {
  		if(Array.isArray(this.innerBlocks[i]))
  		htmlDisplay=htmlDisplay.replace("{["+i+"]}",' <span id="'+this.innerBlocks[i][0]+'" class="modblock" ondrop="drop(event,true)" ondragover="allowDrop(event)"  ondragleave="dragLeave(event)"></span> ');
  		else htmlDisplay=htmlDisplay.replace("{"+i+"}",' <span id="'+this.innerBlocks[i]+'" class="modblock" ondrop="drop(event,false)" ondragover="allowDrop(event)" ondragleave="dragLeave(event)"></span> ');
  		console.log(i)
  	}
  	return htmlDisplay;
  }
}





function OnModuleDropped(where, what){
/*
so basically my idea right now is to make an html generator that will take the contract and display all the element, when something is dropped I get it's ID
and I check inside the contract who is waiting for that ID to come

Or maybe each can handle their own
*/

contractDetails[where]= what;

}
