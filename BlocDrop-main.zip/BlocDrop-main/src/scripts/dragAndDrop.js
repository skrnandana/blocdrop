function allowDrop(ev) {
  ev.preventDefault();
  ev.target.style.backgroundColor="#bfbfbf"
}

function drag(ev) {
	ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev,shouldMakeNewDroppable) {
  ev.preventDefault();
  dragLeave(ev);
  var data = ev.dataTransfer.getData("text");
  OnModuleDropped(ev.target.id,data);
  var moduleObject = blocks[data]();

  var newDroppable;
  if(shouldMakeNewDroppable){
  	newDroppable=ev.target.cloneNode();
  	newDroppable.id = uuidv4();
  	ev.target.setAttribute("next",newDroppable.id );
  }


  ev.target.innerHTML = moduleObject.getDisplay()
  ev.target.classList.add(moduleObject.type);

  if(shouldMakeNewDroppable){
  	ev.target.outerHTML+=newDroppable.outerHTML;
  }

}

function dragLeave(ev) {
	ev.target.style.backgroundColor="#ffffff"
}



//Initialize First droppable
document.getElementById("drop-area").innerHTML = contractDetails["base"].getDisplay();
//Generates draggables
for (var modGen in blocks) {
	var temp = blocks[modGen]();
	document.getElementById("drag-and-drop-elements").innerHTML+=`<div id=${modGen} class="draggable ${temp.type} " draggable="true" ondragstart="drag(event)">${temp.moduleName}</div>`;

}